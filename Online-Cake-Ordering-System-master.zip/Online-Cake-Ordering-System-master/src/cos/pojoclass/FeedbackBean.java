package cos.pojoclass;

public class FeedbackBean {
   String name;
   String mail;
   String mssg;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getMail() {
	return mail;
}
public void setMail(String mail) {
	this.mail = mail;
}
public String getMssg() {
	return mssg;
}
public void setMssg(String mssg) {
	this.mssg = mssg;
}
   
}
