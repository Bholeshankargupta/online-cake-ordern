package cos.pojoclass;

public class ChangePassword {
  String username;
  String newpassword;
  String sessionuser;
  
  public String getSessionuser() {
	return sessionuser;
}
public void setSessionuser(String sessionuser) {
	this.sessionuser = sessionuser;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getNewpassword() {
	return newpassword;
}
public void setNewpassword(String newpassword) {
	this.newpassword = newpassword;
}

  
  
}
