package cos.pojoclass;

public class AddCategory {
  String category;

public String getCategory() {
	return category;
}

public void setCategory(String category) {
	this.category = category;
}
  
}
