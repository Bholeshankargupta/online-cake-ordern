package cos.pojoclass;

public class EmployeeBean {
	int empid;
	String empname;
	String empmobile;
	String empaddress;
	String empjoining;
	String empstatus;
	String emppost;
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public String getEmpmobile() {
		return empmobile;
	}
	public void setEmpmobile(String empmobile) {
		this.empmobile = empmobile;
	}
	public String getEmpaddress() {
		return empaddress;
	}
	public void setEmpaddress(String empaddress) {
		this.empaddress = empaddress;
	}
	public String getEmpjoining() {
		return empjoining;
	}
	public void setEmpjoining(String empjoining) {
		this.empjoining = empjoining;
	}
	public String getEmpstatus() {
		return empstatus;
	}
	public void setEmpstatus(String empstatus) {
		this.empstatus = empstatus;
	}
	public String getEmppost() {
		return emppost;
	}
	public void setEmppost(String emppost) {
		this.emppost = emppost;
	}
	
	
}
