package cos.pojoclass;

public class AddCakeBean {
  String cakename;

public String getCakename() {
	return cakename;
}

public void setCakename(String cakename) {
	this.cakename = cakename;
}
  
}
