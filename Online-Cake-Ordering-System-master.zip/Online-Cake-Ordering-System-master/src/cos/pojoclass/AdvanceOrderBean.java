package cos.pojoclass;

public class AdvanceOrderBean {
    int adorderid;
	String cname;
	long mobile;
	String item;
	String category;
	String odate;
	String ddate;
	float unitprice;
	int quantity; 
	float totalprice;
	float adprice;
	float dueprice;
	String paymentmode;
    String orderstatus;
	public int getAdorderid() {
		return adorderid;
	}
	public void setAdorderid(int adorderid) {
		this.adorderid = adorderid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public long getMobile() {
		return mobile;
	}
	public void setMobile(long mobile) {
		this.mobile = mobile;
	}
	public String getItem() {
		return item;
	}
	public void setItem(String item) {
		this.item = item;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getOdate() {
		return odate;
	}
	public void setOdate(String odate) {
		this.odate = odate;
	}
	public String getDdate() {
		return ddate;
	}
	public void setDdate(String ddate) {
		this.ddate = ddate;
	}
	public float getUnitprice() {
		return unitprice;
	}
	public void setUnitprice(float unitprice) {
		this.unitprice = unitprice;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public float getTotalprice() {
		return totalprice;
	}
	public void setTotalprice(float totalprice) {
		this.totalprice = totalprice;
	}
	public float getAdprice() {
		return adprice;
	}
	public void setAdprice(float adprice) {
		this.adprice = adprice;
	}
	public float getDueprice() {
		return dueprice;
	}
	public void setDueprice(float dueprice) {
		this.dueprice = dueprice;
	}
	public String getPaymentmode() {
		return paymentmode;
	}
	public void setPaymentmode(String paymentmode) {
		this.paymentmode = paymentmode;
	}
	public String getOrderstatus() {
		return orderstatus;
	}
	public void setOrderstatus(String orderstatus) {
		this.orderstatus = orderstatus;
	}  
    
    
}
